from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas, auth, ai_service
from app.database import get_db
from app.financial_engine import compute_financial_health, suggest_settlement_percentage

router = APIRouter(prefix="/api/settlement", tags=["settlement"])


@router.post("/predict", response_model=schemas.SettlementOut, status_code=201)
def predict_settlement(
    payload: schemas.SettlementRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    loan = db.query(models.Loan).filter(
        models.Loan.id == payload.loan_id, models.Loan.owner_id == current_user.id
    ).first()
    if not loan:
        raise HTTPException(status_code=404, detail="Loan not found.")

    all_loans = db.query(models.Loan).filter(models.Loan.owner_id == current_user.id).all()
    health = compute_financial_health(current_user.monthly_income, all_loans)

    settlement_pct = suggest_settlement_percentage(
        outstanding_amount=loan.outstanding_amount,
        overdue_months=loan.overdue_months,
        monthly_surplus=health.monthly_surplus,
    )
    settlement_amount = round(loan.outstanding_amount * settlement_pct / 100, 2)

    ai_summary = ai_service.generate_settlement_summary(
        lender_name=loan.lender_name,
        outstanding_amount=loan.outstanding_amount,
        emi_amount=loan.emi_amount,
        overdue_months=loan.overdue_months,
        monthly_income=current_user.monthly_income,
        emi_ratio=health.emi_ratio,
        debt_stress_label=health.debt_stress_label,
        suggested_settlement_pct=settlement_pct,
    )

    record = models.SettlementRecord(
        loan_id=loan.id,
        monthly_surplus=health.monthly_surplus,
        emi_ratio=health.emi_ratio,
        debt_stress_score=health.debt_stress_score,
        debt_stress_label=health.debt_stress_label,
        suggested_settlement_pct=settlement_pct,
        suggested_settlement_amount=settlement_amount,
        ai_summary=ai_summary,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get("/history/{loan_id}", response_model=list[schemas.SettlementOut])
def settlement_history(
    loan_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    loan = db.query(models.Loan).filter(
        models.Loan.id == loan_id, models.Loan.owner_id == current_user.id
    ).first()
    if not loan:
        raise HTTPException(status_code=404, detail="Loan not found.")

    return (
        db.query(models.SettlementRecord)
        .filter(models.SettlementRecord.loan_id == loan_id)
        .order_by(models.SettlementRecord.created_at.desc())
        .all()
    )
