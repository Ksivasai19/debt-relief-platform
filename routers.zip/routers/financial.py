from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db
from app.financial_engine import compute_financial_health

router = APIRouter(prefix="/api/financial", tags=["financial"])


@router.get("/health", response_model=schemas.FinancialHealthOut)
def get_financial_health(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    loans = db.query(models.Loan).filter(models.Loan.owner_id == current_user.id).all()
    health = compute_financial_health(current_user.monthly_income, loans)
    return schemas.FinancialHealthOut(**health.__dict__)
