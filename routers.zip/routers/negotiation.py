from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas, auth, ai_service
from app.database import get_db
from app.financial_engine import compute_financial_health, suggest_settlement_percentage

router = APIRouter(prefix="/api/negotiation", tags=["negotiation"])


@router.post("/generate-letter", response_model=schemas.NegotiationOut, status_code=201)
def generate_letter(
    payload: schemas.NegotiationRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    loan = db.query(models.Loan).filter(
        models.Loan.id == payload.loan_id, models.Loan.owner_id == current_user.id
    ).first()
    if not loan:
        raise HTTPException(status_code=404, detail="Loan not found.")

    all_loans = db.query(models.Loan).filter(models.Loan.owner_id == current_user.id).all()
    health = compute_financial_health(current_user.monthly_income, all_loans)
    settlement_pct = suggest_settlement_percentage(
        outstanding_amount=loan.outstanding_amount,
        overdue_months=loan.overdue_months,
        monthly_surplus=health.monthly_surplus,
    )
    settlement_amount = round(loan.outstanding_amount * settlement_pct / 100, 2)

    letter_text = ai_service.generate_negotiation_letter(
        lender_name=loan.lender_name,
        loan_type=loan.loan_type,
        outstanding_amount=loan.outstanding_amount,
        emi_amount=loan.emi_amount,
        overdue_months=loan.overdue_months,
        monthly_income=current_user.monthly_income,
        suggested_settlement_pct=settlement_pct,
        suggested_settlement_amount=settlement_amount,
        letter_type=payload.letter_type,
        tone=payload.tone,
        additional_context=payload.additional_context,
    )

    record = models.NegotiationHistory(
        loan_id=loan.id,
        letter_type=payload.letter_type,
        generated_text=letter_text,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get("/history/{loan_id}", response_model=list[schemas.NegotiationOut])
def negotiation_history(
    loan_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    loan = db.query(models.Loan).filter(
        models.Loan.id == loan_id, models.Loan.owner_id == current_user.id
    ).first()
    if not loan:
        raise HTTPException(status_code=404, detail="Loan not found.")

    return (
        db.query(models.NegotiationHistory)
        .filter(models.NegotiationHistory.loan_id == loan_id)
        .order_by(models.NegotiationHistory.created_at.desc())
        .all()
    )
